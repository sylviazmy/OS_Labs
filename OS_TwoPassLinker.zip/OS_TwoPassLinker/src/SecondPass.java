import java.util.ArrayList;
import java.util.HashMap;

public class SecondPass {
	
	public ArrayList<Module> modules;
	public ArrayList<Symbol> AllDefList;
	public ArrayList<Symbol> CurrDefList;
	public ArrayList<Symbol> CurrUseList;
	public ArrayList<ProgText> CurrProgTextList;
	public HashMap<Integer,Integer> MemoryMap;
	public ArrayList<String> WarningMsg;
	public ArrayList<String> ErrorMsg;
	public SecondPass(ArrayList<Module> modules,ArrayList<Symbol> AllDefList) {
		this.modules=modules;
		this.AllDefList=AllDefList;
	}
	
	public SecondPass(ArrayList<Symbol> DefList,ArrayList<Symbol> UseList,ArrayList<ProgText> ProgTextList)
	{
		
	}
	public HashMap<Integer,Integer> processSecondPass(ArrayList<Module> modules,
			ArrayList<Symbol> AllDefList,ArrayList<String> ErrorMsg1,ArrayList<String> WarningMsg1) {
		
		MemoryMap=new HashMap<Integer,Integer>();
		WarningMsg=new ArrayList<String>();
		ErrorMsg=new ArrayList<String>();
		ErrorMsg=ErrorMsg1;
		WarningMsg=WarningMsg1;
		HashMap<Integer,Integer> moduleSize=new HashMap<Integer,Integer>();
		int key=0;
//		String msg="";
		int moduleNO=0;

		for(Module m:modules) {
			moduleSize.put(key, m.getModuleSize());
			int absAddress=m.getAddress();
//			System.out.print("Address is :"+absAddress+"\n");
			CurrUseList=m.getUseList();
			CurrDefList=m.getDefList();
			CurrProgTextList=m.getProgText();
//			for(int u=0;u<CurrUseList.size();u++) {
//				CurrUseList.get(u).setTextFlag();
//			}

			for(int i=0;i<CurrProgTextList.size();i++) {
				int textAddr=CurrProgTextList.get(i).getInstruction()%1000;
				int textOp=CurrProgTextList.get(i).getInstruction()/1000;
//				CurrProgTextList.add(CurrProgTextList.get(i));
				char type=CurrProgTextList.get(i).getType();
				int word=CurrProgTextList.get(i).getInstruction();				
				if(type=='R') {
					if(textAddr<m.getModuleSize()) {
				    int newabsAddress=absAddress+word;
					MemoryMap.put(key, newabsAddress);
					ErrorMsg.add("");
					}
					else {
						String msg=" Error: Relative address exceeds module size; zero used.";
						MemoryMap.put(key, textOp*1000);
						ErrorMsg.add(msg);
					}
				}
				else if(type=='I') {
					MemoryMap.put(key, word);
					ErrorMsg.add("");
				}
				else if (type=='A') {
					if(textAddr<200) {
						MemoryMap.put(key, word);
						ErrorMsg.add("");
					}
					else {
						String msg=" Error: Absolute address exceeds machine size; zero used.";
						MemoryMap.put(key,textOp*1000);
						ErrorMsg.add(msg);
					}
					
				}
				else if(type=='E') {
//					System.out.print("Found it!\n");
//					int addr=CurrUseList.get(textAddr).getRelAddress()+textOp*1000;
					int newAddr=0;
					if(textAddr<CurrUseList.size()) {
					for(int i1=0;i1<AllDefList.size();i1++)
					{
//						System.out.print("Found it!\n");
						if(AllDefList.get(i1).getSymName().equals(CurrUseList.get(textAddr).getSymName())) {
							newAddr=AllDefList.get(i1).getRelAddress();
							AllDefList.get(i1).changeFlag();
//							System.out.print("Found it!\n");
						}
					}
					int addr=newAddr+textOp*1000;
					if(newAddr>0&&textAddr<CurrUseList.size()) {					
//					System.out.print("the address of uses is :"+addr);
					MemoryMap.put(key,addr);
					ErrorMsg.add("");
					CurrUseList.get(textAddr).setTextFlag();
//					System.out.print("set flag\n:"+CurrUseList.get(textAddr));
					}

					else {
						String msg=" Error: "+CurrUseList.get(textAddr).getSymName()+" is not defined; zero used.";
						MemoryMap.put(key,addr);
						ErrorMsg.add(msg);
						CurrUseList.get(textAddr).setTextFlag();
					}
					}
					else {
						String msg=" Error: External address exceeds length of use list; treated as immediate.";
						MemoryMap.put(key,word);
						ErrorMsg.add(msg);
					}
				}
				
				
//					else WarningMsg.add(""); 
				
			
				key++;
			}
//			System.out.print("\nsize:"+CurrUseList.size());
			for(int u=0;u<CurrUseList.size();u++) {
				if(!CurrUseList.get(u).getTextFlag()) {
					String msg="Warning: In module "+moduleNO+" "+CurrUseList.get(u).getSymName()+" appeared in the use list but was not actually used.";
					WarningMsg.add(msg);						
				}
			}
			moduleNO++;
		}
		System.out.print("\nMemory Map");
		for(int i=0;i<MemoryMap.size();i++) {
			System.out.print("\n"+i+":    "+MemoryMap.get(i)+ErrorMsg.get(i));
		}
		System.out.print("\n");
		for(Symbol e:AllDefList) {
			if(!e.getFlag()) {
				System.out.print("\nWarning: "+e.getSymName()+" was "+ "defined "
						+ "in module "+e.getModuleNO()+" but never used.");
			}
		}
	
		for(String str:WarningMsg) {
			System.out.print("\n"+str);
		}
		return MemoryMap;
		
	}
	

}
