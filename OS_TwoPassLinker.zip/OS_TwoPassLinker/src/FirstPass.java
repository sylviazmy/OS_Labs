import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class FirstPass {
	private int numofModules;
	private ArrayList<String> input;
	public ArrayList<Symbol> DefList;
	public ArrayList<Symbol> UseList;
	public ArrayList<ProgText> ProgTextList;
	public ArrayList<Module> moduleList;
	public ArrayList<String> ErrorMsg;
	public ArrayList<String> WarningMsg;
	public HashMap<Integer,String> DuplMsg;
	public ArrayList<String> getError(){
		return this.ErrorMsg;
	}
	public ArrayList<String> getWarning(){
		return this.WarningMsg;
	}
	public FirstPass(int num,ArrayList<String> input) {
		this.numofModules=num;		
		this.input=input;
	}
	public ArrayList<Module> addModuleList(int num,ArrayList<String> input){
		int startLoc=0;
		int arrayStop=0;
		int count;
		
		this.moduleList= new ArrayList<Module>();
		input.add("0");
		while(num>0) {
			num--;
			count=arrayStop;
//			startLoc=arrayStop;
//			System.out.print("the first index of module input:"+arrayStop+"\n");
			ArrayList<String> module=new ArrayList<String>();			
			for(int i=arrayStop+1;i<input.size();i++) {
				String str=input.get(i-1);
				String str1=input.get(i);
				
				String pattern="^[0-9]*$";
				Pattern r=Pattern.compile(pattern);
				Matcher m=r.matcher(str1);
				
				if((str.length()==4&&str1.matches(pattern)))
				{
					count++;
					module.add(str);
					arrayStop=count;
					Module moduleContent= new Module(startLoc,module);
//					moduleContent.setSection(module);
					startLoc=startLoc+moduleContent.ProgTextList.size();
//					System.out.print("size of module:"+module.size()+"\n");
//					System.out.print(module.toString());
					moduleList.add(moduleContent);
					break;
				}
				else {
					module.add(str);
					count++;
				}
				
			}

		}
//		System.out.print("the lenth of modulelist:"+moduleList.size()+"\n");
		return moduleList;
		
	}
	/*
	 * return all the definitions defined in modules
	 */
	public ArrayList<Symbol> Definitions(){
		DefList=new ArrayList<Symbol>();
		Set<String> nameSet=new HashSet();
		HashMap<String,Integer> nameset=new HashMap<String,Integer>();
		ErrorMsg= new ArrayList<String>();
		WarningMsg=new ArrayList<String>();
		DuplMsg=new HashMap<Integer,String>();
		int NO=0;
		int key=0;
		for(Module m:this.moduleList) {
			for(Symbol s:m.DefList) {
//				s.addModuleNO(NO);			
				String name=s.getSymName();
				int location=s.getRelAddress();
				int OriLoc=s.getOriLoc();
				Symbol symbol=new Symbol(name,location,OriLoc);
				if(OriLoc>m.getModuleSize()) {
//					symbol.changeAddr(OriLoc);
//					System.out.print("OriLoc:"+OriLoc);
					String msg="Error: In module "+ NO+" the def of "+name+" exceeds the module size; zero (relative) used.";
					this.WarningMsg.add(msg);
				}
				
				
				symbol.addModuleNO(NO);
				if(nameset.containsKey(name)) {
					String msg=" Error: This variable is multiply defined; first value used.\n";
					DuplMsg.put(nameset.get(name), msg);
//					System.out.print(" Error: This variable is multiply defined; first value used.\n");
				}
//				else if(s.getRelAddress()>m.getModuleSize()) {
//					s.changeAddr(OriLoc);
//					DefList.add(s);
//					nameSet.add(name);
//				}
				else {
					DefList.add(symbol);  
					nameSet.add(name);
					nameset.put(name, key);
					key++;
				}
			

				}	
			NO++;
			}
			
//		
		int count=0;
		for(Symbol it:DefList) {
//			System.out.print(it.toString());
			if(DuplMsg.containsKey(count)) {
				System.out.print(it.getSymName()+"="+it.getRelAddress()+DuplMsg.get(count));
			}
			else {
				System.out.print(it.toString());
			}
			count++;
		}	
		return DefList;		
	}
}
