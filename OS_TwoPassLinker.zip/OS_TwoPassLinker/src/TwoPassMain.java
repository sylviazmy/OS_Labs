import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class TwoPassMain {
	
	public TwoPassMain(String input) throws FileNotFoundException {
		String token;
		int numofModule=0;
		int numofDef=0;
		int numofUse=0;
		int numofText=0;
		ArrayList<String> inputText= new ArrayList<String>();
		ArrayList<Module> modules= new ArrayList<Module>();
		ArrayList<Symbol> DefList=new ArrayList<Symbol>();
		File f = new File(input);

		Scanner scanner = new Scanner(new File(input));		
		String content = scanner.useDelimiter("\\A").next();//'\A' matches the beginning of the string

		Matcher m= Pattern.compile("[\\d\\w]+").matcher(content);		
		while(m.find()) {			
			token=m.group();
			inputText.add(token);
//			System.out.print(token+" "+token.length()+"\n");
		}
		
/*
 * FirstPass:
 * 
 */
		numofModule=Integer.parseInt(inputText.get(0));
		inputText.remove(0);
		FirstPass firstPass=new FirstPass(numofModule,inputText);
		modules=firstPass.addModuleList(numofModule, inputText);
		System.out.print("Symbol Table"+"\n");
		DefList=firstPass.Definitions();
/*
 * SecondPass:
 */
		SecondPass secondPass=new SecondPass(modules,DefList);
		secondPass.processSecondPass(modules,DefList,firstPass.getError(),firstPass.getWarning());
		
	}

	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
		String FilePath;
		if(args.length >0)
			FilePath=args[0];
		else
			throw new IllegalArgumentException("\n input unfound\n");
		new TwoPassMain(FilePath);
		
	}

}
