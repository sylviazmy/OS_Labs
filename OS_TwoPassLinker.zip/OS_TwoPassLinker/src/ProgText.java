public class ProgText {
	private char addrType;
	private int instruction;
	public ProgText(char addrType, int instruction) {
		this.addrType=addrType;
		this.instruction=instruction;
		
	}
	public String toString() {
		return this.addrType +":  "+ this.instruction + "\n";
	}
	public char getType() {
		return this.addrType;
	}
	public int getInstruction(){
		return this.instruction;
	}

}
