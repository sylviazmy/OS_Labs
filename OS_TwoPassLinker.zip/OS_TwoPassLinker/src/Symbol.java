public class Symbol {
	private String symName;
	private Integer relAddress;
	private Integer defaultrelAddress;
	private boolean usedFlag;
	private Integer moduelNO;
	private boolean textusedFlag;
	public Symbol(String symName,int location,int oriLoc) {
		this.symName=symName;
		this.relAddress=location;	
		this.usedFlag=false;
		this.moduelNO=null;
		this.defaultrelAddress=oriLoc;
		this.textusedFlag=false;
	}
	public Symbol(String symName) {
		this.symName=symName;
		this.relAddress=null;
		this.usedFlag=false;
		this.moduelNO=null;
		this.defaultrelAddress=null;
		this.textusedFlag=false;
	}

	public int getOriLoc() {
		return this.defaultrelAddress;
	}
	public String getSymName() {
		return this.symName;
	}
	public Integer getRelAddress() {
		return this.relAddress;
	}
	public boolean changeFlag() {
		this.usedFlag=true;
		return this.usedFlag;
	}
	public boolean getFlag() {
		return this.usedFlag;
	}
	public void setTextFlag() {
		this.textusedFlag=true;
	}
	public boolean getTextFlag() {
		return this.textusedFlag;
	}
	public void addModuleNO(int n) {
		this.moduelNO=n;
	}
	public int getModuleNO() {
		return this.moduelNO;
	}
	public int changeAddr(int add) {
		return this.relAddress=add;
	}
	public String toString() {
		StringBuilder sb=new StringBuilder();
		sb.append(this.symName + "=" + this.relAddress +"\n");
		return sb.toString();
	}

}
