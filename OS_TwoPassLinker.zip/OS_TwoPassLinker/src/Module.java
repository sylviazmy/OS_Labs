import java.util.ArrayList;

public class Module {
	private int startLoc;//absolute address
	private int endLoc;
	private int len;
	public ArrayList<String> moduleInput;
	public ArrayList<Symbol> DefList;
	public ArrayList<Symbol> UseList;
	public ArrayList<ProgText> ProgTextList;
//	public Module(int startLoc,ArrayList<String> moduleInput) {
//		this.moduleInput=moduleInput;
//		this.startLoc=startLoc;
//		this.endLoc=startLoc;
//		this.len=0;
//		System.out.print("absolute start address for this module is:"+startLoc+"\n");
//	}
	public void addDefList(Symbol symbol) {
		this.DefList.add(symbol);
	}
	public void addUseList(Symbol symbol) {
		UseList.add(symbol);
	}
	public void addProgramTextList(ProgText text) {
		this.ProgTextList.add(text);
	}
	public ArrayList<Symbol> getDefList(){
		return this.DefList;
	}
	public ArrayList<Symbol> getUseList() {
		return this.UseList;
	}
	
	public ArrayList<ProgText> getProgText(){
		return this.ProgTextList;
	}
	public int getAddress() {
		return startLoc;
	}
	public int getModuleSize() {
		return this.len;
	}

	public void setList(ArrayList<String> moduleInput) {
		
	}
	public Module(int startLoc,ArrayList<String> moduleInput) {
		this.moduleInput=moduleInput;
		this.startLoc=startLoc;
		this.endLoc=startLoc;
		this.len=0;
//		System.out.print("absolute start address for this module is:"+startLoc+"\n");
		int indexofDef=0;
		int numofDef=Integer.parseInt(moduleInput.get(indexofDef));
		int indexofUse=2*numofDef+1;
		int numofUse=Integer.parseInt(moduleInput.get(indexofUse));
		int indexofIns=2*numofDef+numofUse+2;
		int numofIns=Integer.parseInt(moduleInput.get(indexofIns));
		this.DefList=new ArrayList<Symbol>();
		this.UseList=new ArrayList<Symbol>();
		this.ProgTextList=new ArrayList<ProgText>();
		for(int i=indexofDef+1;i<indexofUse;i+=2) {
			Symbol s=new Symbol(moduleInput.get(i),startLoc+Integer.parseInt(moduleInput.get(i+1)),Integer.parseInt(moduleInput.get(i+1)));
//			this.addDefList(s);
			this.DefList.add(s);		
		}
		for(int j=indexofUse+1;j<indexofIns;j++) {
			int relAddress=j-indexofUse-1;
			Symbol s=new Symbol(moduleInput.get(j),relAddress,relAddress);
//			System.out.print("relative address: "+moduleInput.get(j)+"="+relAddress+"\n");
//			this.addUseList(s,UseList);
			this.UseList.add(s);
		}
		for(int q=indexofIns+1;q<moduleInput.size();q+=2) {
			ProgText t=new ProgText(moduleInput.get(q).charAt(0),Integer.parseInt(moduleInput.get(q+1)));
			this.ProgTextList.add(t);
			this.len++;
		}
		

	}
	

}
